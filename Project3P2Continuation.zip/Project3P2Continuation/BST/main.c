#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"bst.h"

int main() {

    // Starting tests for the binary tree

    return 0;
}
